# Image processor API

You will need to run `npm i` before testing

 - To start the server `npm run start`
 - To run the tests `npm run test`
 - To run the formatter `npm run format`
 - To build `npm run build`